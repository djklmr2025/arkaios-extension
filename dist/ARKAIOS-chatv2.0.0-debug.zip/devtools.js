chrome.devtools.panels.create(
  "ARKAIOS Debug",
  "",
  "devtools_panel.html",
  () => {}
);
