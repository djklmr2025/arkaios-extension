const logEl = document.getElementById('log');
const log = (...a)=>{ logEl.textContent += a.join(' ') + '\n'; logEl.scrollTop = logEl.scrollHeight; };

document.getElementById('btnPing').onclick = ()=>{
  chrome.runtime.sendMessage({type:'DEBUG_PING'}, res=>{
    log('PING =>', JSON.stringify(res));
  });
};
document.getElementById('btnClear').onclick = ()=>{ logEl.textContent=''; };
document.getElementById('btnFollow').onclick = ()=>{
  chrome.runtime.sendMessage({type:'DEBUG_FOLLOW_START'}, _=>{ log('Follow ON'); });
};
