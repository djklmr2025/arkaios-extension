# ARKAIOS Lab Gateway – Chat Module (Debug)
Build de depuración para trazas y pruebas internas.
- Versión: 2.0.0-debug
- Fecha: 2025-10-06

## Qué incluye
- DevTools panel (**ARKAIOS Debug**) con Ping/Follow.
- Logs detallados en background y content (prefijo `[ARKAIOS]`).
- Misma funcionalidad que Stable para probar overlay/panel/ventana.
